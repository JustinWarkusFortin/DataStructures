import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * This class contains the dynamically allocated array and it's processing
 * Student Name: Justin-Thomas Warkus-Fortin
 * Student Number:  040966794
 * Course: CST8130 - Data Structures     :  CET-CS-Level 3
 * @author/Professor James Mwangi PhD. 
 * @author Linda Crane
 * @author Melissa Sienkiewicz
 */
public class Numbers {
	
	private Float[] numbers;
	private int numItems = 0;
	 
	

	/**
	 * Default Constructor
	 */
	public Numbers() {
		numbers = new Float[10];
		numItems = 0;
	}

	/**
	 * Constructor that initializes the numbers array.
	 * @param size - Max size of the numbers array
	 */
	public Numbers(int size) {
		numbers = new Float[size];
		numItems = 0;
	}
	
	/**
	 * Adds a value in the array
	 * @param keyboard - Scanner object to use for input
	 */

	public void addValue(Scanner keyboard) {
		try {
			numbers[numItems] = keyboard.nextFloat();
			numItems++;
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.print("Array Full!\n");
		}catch (InputMismatchException e) {
			System.out.print("Invalid symbol!\n");
		}
	}
	
	/**
	 * Calculates the average of all the values in the numbers array.
	 * @return float value that represents the average
	 */
	public float calcAverage() {
		float average = 0;
		if(numItems != 0) {
			for(int i = 0; i < numItems; i++) {
				average += numbers[i];
			}
			average = average/numItems;
		return (float) average;
		}
		return 0.0f;
	}

	@Override
	public String toString() {
		String words = "";
		for(int i = 0; i < numItems; i++) {
			words += numbers[i] + "\n";
		
		}
		return words; 
	}
	public float findMedian() {
			List<Float> li = Arrays.asList(numbers);
			Collections.sort(li);
			float median;
			double totalNumbers = numbers.length;
			if (totalNumbers % 2 == 0) {
				float sumOfMiddleElements = numbers[ (numItems / 2)] + numbers[ (numItems / 2 - 1)];
				median = (sumOfMiddleElements) / 2;
				return median;
			} 
			else if(totalNumbers % 2 != 0){
				median = numbers[numbers.length / 2];
				return median;
			}
			return 0.0f;
		}
	
}
